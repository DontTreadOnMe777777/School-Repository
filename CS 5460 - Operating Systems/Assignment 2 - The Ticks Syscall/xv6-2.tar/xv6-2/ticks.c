#include "types.h"
#include "stat.h"
#include "user.h"

int
main(int argc, char *argv[])
{
  int startup = uptime();
  int ticksToWait = atoi(argv[1]);
  while (uptime() - startup < ticksToWait)
  {
  }
  printf(1, "%d \n", getticks());
  exit();
}
