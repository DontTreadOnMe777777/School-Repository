#include "types.h"
#include "user.h"
#include "stat.h"

int
main(int argc, char *argv[])
{
  // If we have the wrong number of arguments, report and exit
  if (argc != 3)
  {
    printf(1, "Incorrect number of arguments, try again!", argc);
    exit();
  }

  // Get our number of tickets and then call our settickets() method
  int numberOfTickets = atoi(argv[1]);
  settickets(numberOfTickets);
  
  // Create a new argument array and fill it with our remaining argument(s), which should be the program to execute and
  // any remaining tags (such as &)
  char* remainingArgs[1];
  remainingArgs[0] = argv[2];
  
  // Finally, execute the specified program with our remaining arguments
  exec(argv[2],remainingArgs);
  exit();
}
