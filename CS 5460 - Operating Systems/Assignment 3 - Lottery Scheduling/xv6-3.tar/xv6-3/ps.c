#include "types.h"
#include "stat.h"
#include "user.h"
#include "pstat.h"

int
main(int argc, char *argv[])
{
  int p;
  // If wrong number of args, return with error code
  if (argc > 2){
    return -1;
  }

  // This is the pstat table that we will give to getpinfo() to get the info of our processes
  struct pstat* pStatTable = (struct pstat*)malloc(sizeof(struct pstat));
  
  // If we have no -r flag
  if (argc == 1)
  {
	// Get our required info
    getpinfo(pStatTable);
    printf(1,"PID TICKETS TICKS\n");
	// Print only our active processes!
    for (p = 0; p < NPROC; p++)
	{
      if (pStatTable->inuse[p])
	  {
        printf(1, "%d %d %d\n", pStatTable->pid[p], pStatTable->tickets[p], pStatTable->ticks[p]);
	  }
    }
  }
  
  // If we have a -r flag, we must loop every 100 ticks
  if (argc == 2 && strcmp(argv[1],"-r") ==0)
  {
    while (1)
	{
	  // Get our required info
      getpinfo(pStatTable);
      printf(1,"PID TICKETS TICKS\n");
	  // Print only our active processes!
      for (p = 0; p < NPROC; p++)
	  {
        if (pStatTable->inuse[p])
		{
          printf(1, "%d %d %d\n", pStatTable->pid[p], pStatTable->tickets[p], pStatTable->ticks[p]); 
		}
      }
	  // Sleep for 100 ticks, then repeat the print infinitely
      sleep(100);
    }
  }
  return 0;
}
