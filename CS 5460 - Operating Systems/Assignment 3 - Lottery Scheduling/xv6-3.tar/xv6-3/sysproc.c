#include "types.h"
#include "x86.h"
#include "defs.h"
#include "date.h"
#include "param.h"
#include "memlayout.h"
#include "mmu.h"
#include "proc.h"
#include "pstat.h"

int
sys_fork(void)
{
  return fork();
}

int
sys_exit(void)
{
  exit();
  return 0;  // not reached
}

int
sys_wait(void)
{
  return wait();
}

int
sys_kill(void)
{
  int pid;

  if(argint(0, &pid) < 0)
    return -1;
  return kill(pid);
}

int
sys_getpid(void)
{
  return myproc()->pid;
}

int
sys_sbrk(void)
{
  int addr;
  int n;

  if(argint(0, &n) < 0)
    return -1;
  addr = myproc()->sz;
  if(growproc(n) < 0)
    return -1;
  return addr;
}

int
sys_sleep(void)
{
  int n;
  uint ticks0;

  if(argint(0, &n) < 0)
    return -1;
  acquire(&tickslock);
  ticks0 = ticks;
  while(ticks - ticks0 < n){
    if(myproc()->killed){
      release(&tickslock);
      return -1;
    }
    sleep(&ticks, &tickslock);
  }
  release(&tickslock);
  return 0;
}

// return how many clock tick interrupts have occurred
// since start.
int
sys_uptime(void)
{
  uint xticks;

  acquire(&tickslock);
  xticks = ticks;
  release(&tickslock);
  return xticks;
}

// Our method to set a process' tickets. We get the number from our arguments and insert it into the
// tickets property of our current process, myproc()
int 
sys_settickets(void)
{
  int numberOfTickets;
  // If ticket number is negative, return with error
  if(argint(0, &numberOfTickets) < 0)
  {
    return -1;
  }
  // Set our tickets in the current process to our newly received number
  myproc()->tickets = numberOfTickets;
  return 0;
}

// Our method to get information from our assorted processes. We get the pstat table from our arguments
// and give it to our getpinfo() function in proc.c to fill out (since it's a reference, we don't need to return it!)
int 
sys_getpinfo(void)
{
  struct pstat *pStatTable;
  // If an invalid pointer, return with error
  if(argptr(0, (char**)&pStatTable, 1) < 0)
  {
    return -1;
  }
  // Call our proc.c function getprocinfo() with our pstat table to be filled out
  getpinfo(pStatTable);
  return 0;
}